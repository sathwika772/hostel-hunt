// Populate the girls and boys hostel drop-down boxes based on the selected location
document.querySelector('#location').addEventListener('change', function() {
  var locationId = this.value;
  var girlsHostelDropdown = document.querySelector('#girls_hostel');
  var boysHostelDropdown = document.querySelector('#boys_hostel');

  // Clear the existing hostel options
  girlsHostelDropdown.innerHTML = '';
  boysHostelDropdown.innerHTML = '';

  // Fetch the hostel names for the selected location
  fetch('get-hostels.php?location_id=' + locationId)
    .then(response => response.json())
    .then(hostels => {
      // Populate the girls and boys hostel drop-down boxes with the hostel names
      for (var i = 0; i < hostels.length; i++) {
        var hostel = hostels[i];
        girlsHostelDropdown.innerHTML += '<option value="' + hostel.id + '">' + hostel.name + '</option>';
        boysHostelDropdown.innerHTML += '<option value="' + hostel.id + '">' + hostel.name + '</option>';
      }
    });
});
